./configure --prefix=/usr
make
make install
make modules_install
/sbin/modprobe openvswitch

export PATH=$PATH:/usr/share/openvswitch/scripts
ovs-ctl start

export PATH=$PATH:/usr/share/openvswitch/scripts
ovs-ctl --no-ovs-vswitchd start

export PATH=$PATH:/usr/share/openvswitch/scripts
ovs-ctl --no--ovsdb-server start

mkdir -p /etc/openvswitch
ovsdb-tool create /etc/openvswitch/conf.db \
    vswitchd/vswitch.ovsschema

mkdir -p /var/run/openvswitch
ovsdb-server --remote=punix:/var/run/openvswitch/db.sock \
    --remote=db:Open_vSwitch,Open_vSwitch,manager_options \
    --private-key=db:Open_vSwitch,SSL,private_key \
    --certificate=db:Open_vSwitch,SSL,certificate \
    --bootstrap-ca-cert=db:Open_vSwitch,SSL,ca_cert \
    --pidfile --detach --log-file

ovs-vsctl --no-wait init
ovs-vswitchd --pidfile --detach --log-file
