1. set your correct IP and NIC id(such as enp1s0) in interfaces
2. change the shell script as you need
3. sudo ./build.sh

