#!/bin/bash
# Ubuntu18.04基础环境配置 2020-12-1

# 步骤1：设置静态ip与DNS
echo "Step 1 --- Configure static ip and DNS ---"
mv /etc/network/interfaces /etc/network/interfaces.backup
cp -a ./interfaces /etc/network/interfaces
service networking restart
sleep 2

sed -i 's/#DNS=/DNS=114.114.114.114/g' /etc/systemd/resolved.conf
service systemd-resolved restart
sleep 2

# 步骤2：更换国内apt源，并更新软件
echo "Step 2 --- Replace domestic apt source and update software ---"
mv /etc/apt/sources.list /etc/apt/sources.list.backup
cp -a ./sources.list /etc/apt/sources.list
apt-get update
sleep 2
apt-get -y upgrade
sleep 2

# 步骤3-1：安装vim
echo "Step 3-1 --- Install vim ---"
apt-get remove -y vim-common
apt-get install -y vim

# 步骤3-2：安装ip、ifconfig、ping、traceroute、w3m
echo "Step 3-2 --- Install ip、ifconfig、ping、traceroute、w3m ---"
apt-get install -y iproute2 net-tools iputils-ping traceroute w3m

# 步骤3-3：安装pip2、pip3，并更换国内源
echo "Step 3-3 --- Install pip2、pip3 and replace the domestic source ---"
apt-get install -y python-pip python3-pip
mkdir ~/.pip
cp -a ./pip.conf ~/.pip/pip.conf
ln -s /usr/bin/pip2 /usr/bin/pip2.7
ln -s /usr/bin/pip3 /usr/bin/pip3.6
rm -f /usr/bin/pip
ln -s /usr/bin/pip3 /usr/bin/pip
rm -f /usr/bin/python
ln -s /usr/bin/python3 /usr/bin/python

# 步骤3-4：安装文件上传/下载工具lrzsz、同步工具rsync
echo "Step 3-4 --- Install lrzsz、rsync ---"
apt-get install -y lrzsz rsync

# 步骤3-5：安装ssh-server、autossh
echo "Step 3-5 --- Install ssh-server、autossh ---"
apt-get install -y openssh-server autossh
service ssh start
# 通过chpass.txt修改root账号密码,并允许root账号可以远程使用ssh登录
chpasswd < chpass.txt
sed -i 's/#PermitRootLogin prohibit-password/PermitRootLogin yes/g' /etc/ssh/sshd_config
service ssh restart

# 步骤3-6：安装发包工具、流量统计工具netperf、iperf、iftop、vnstat
echo "Step 3-6 --- Install netperf、iperf、iftop、vnstat ---"
apt-get install -y netperf iperf iftop vnstat

# 步骤3-7：安装docker.io
echo "Step 3-7 --- Install docker.io ---"
apt-get install -y docker.io

# 步骤3-8：安装OVS
echo "Step 3-8 --- Install OVS ---"
apt-get install -y openvswitch-switch

# 步骤3-9：安装KVM管理工具
echo "Step 3-9 --- Install KVM manager tools ---"
apt-get install -y qemu-kvm qemu virt-manager libvirt-bin bridge-utils

# 步骤4：启动ipv4转发
echo "Step 4 --- Configure IPv4 forwarding ---"
# 编辑/etc/sysctl.conf文件永久启用ip_forward,将net.ipv4.ip_forward=1前的#号去掉
sed -i 's/#net.ipv4.ip_forward=1/net.ipv4.ip_forward=1/g' /etc/sysctl.conf
# 执行以下指令，让设置立刻生效：
sysctl -p /etc/sysctl.conf
# 加载内核模块
modprobe ip_conntrack
# 设置filter表基础策略：允许入包/出包/转发（可进一步细化）
iptables -P INPUT ACCEPT
iptables -P OUTPUT ACCEPT
iptables -P FORWARD ACCEPT
# 设置基础会话规则
iptables -A FORWARD -m state --state RELATED,ESTABLISHED -j ACCEPT

# 步骤5：外网连通保活
echo "Step 6 --- Configure extranet connection keepalive ---"
ping -i 60 www.baidu.com &

reboot
