.. include:: ../../HACKING.rst
