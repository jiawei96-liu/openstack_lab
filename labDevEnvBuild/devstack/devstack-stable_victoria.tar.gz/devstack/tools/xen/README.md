Note: XenServer relative tools have been moved to `os-xenapi`_ and be maintained there.

.. _os-xenapi: https://opendev.org/x/os-xenapi/
